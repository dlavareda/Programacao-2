#include <stdio.h>
#include "recursividade.h"

int main(){
    float *v, m;
    int tam;
    v = LerVectorFloatFicheiro("/home/dlavareda/Documents/Programação 2/Folha 6 - Recursividade/float.txt", &tam);
    m = media(v, tam, tam);
    printf("media = %f\n", m);
    return 1;
}